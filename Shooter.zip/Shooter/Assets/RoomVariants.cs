using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomVariants : MonoBehaviour
{
    public GameObject[] topRooms;
    public GameObject[] buttomRooms;
    public GameObject[] rightRooms;
    public GameObject[] leftRooms;

    public GameObject key;
    public GameObject gun;

    [HideInInspector] public List<GameObject> room;

    private void Start()
    {
        StartCoroutine(RandomSpawner());
    }
    IEnumerator RandomSpawner()
    {
        yield return new WaitForSeconds(5f);
        AddRooms lastRoom = room[room.Count - 1].GetComponent<AddRooms>();
        int rand = Random.Range(0, room.Count - 2);

        Instantiate(key, room[rand].transform.position, Quaternion.identity);
        Instantiate(gun, room[room.Count -2].transform.position, Quaternion.identity);

        lastRoom.door.SetActive(true);
        lastRoom.DestroyWalls();
    }
}
